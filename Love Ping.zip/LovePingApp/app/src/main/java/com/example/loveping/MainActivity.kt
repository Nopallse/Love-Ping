package com.example.loveping

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.loveping.databinding.ActivityMainBinding
import com.google.android.material.animation.AnimatorSetCompat.playTogether
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var vibrator: Vibrator
    private var partnerToken: String? = null
    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        // Hardcoded UID pasangan
        val currentUser = auth.currentUser?.uid
        partnerToken = when (currentUser) {
            "CN69bMqR8HPCK7fb29G7UfoOqPM2" -> "jwtVJU0Z5YXt0TFNAy5ucy1I39d2"
            "jwtVJU0Z5YXt0TFNAy5ucy1I39d2" -> "CN69bMqR8HPCK7fb29G7UfoOqPM2"
            else -> null
        }

        binding.heartButton.setOnClickListener {
            sendHeartbeat()
            animateHeart()
        }

        // Dengarkan heartbeat dari pasangan
        listenToHeartbeats()
    }

    private fun animateHeart() {
        val scaleX = ObjectAnimator.ofFloat(binding.heartButton, "scaleX", 1f, 1.2f, 1f)
        val scaleY = ObjectAnimator.ofFloat(binding.heartButton, "scaleY", 1f, 1.2f, 1f)
        AnimatorSet().apply {
            playTogether(scaleX, scaleY)
            duration = 500
            start()
        }
    }

    private fun listenToHeartbeats() {
        val currentUser = auth.currentUser?.uid
        db.collection("heartbeats")
            .whereEqualTo("receiver", currentUser)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    return@addSnapshotListener
                }
                snapshots?.documentChanges?.forEach { doc ->
                    if (doc.type == DocumentChange.Type.ADDED) {
                        vibrate()
                        animateHeart()
                    }
                }
            }
    }

    private fun vibrate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(500)
        }
    }



    private fun sendHeartbeat() {
        partnerToken?.let { token ->
            db.collection("heartbeats").add(
                hashMapOf(
                    "sender" to auth.currentUser?.uid,
                    "receiver" to token,
                    "timestamp" to FieldValue.serverTimestamp()
                )
            )
        }
    }

}